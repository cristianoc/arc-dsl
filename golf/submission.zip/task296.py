
F = False
T = True

ZERO = 0
ONE = 1
TWO = 2
THREE = 3
FOUR = 4
FIVE = 5
SIX = 6
SEVEN = 7
EIGHT = 8
NINE = 9
TEN = 10

NEG_ONE = -1
NEG_TWO = -2

DOWN = (1, 0)
RIGHT = (0, 1)
UP = (-1, 0)
LEFT = (0, -1)

ORIGIN = (0, 0)
UNITY = (1, 1)
NEG_UNITY = (-1, -1)
UP_RIGHT = (-1, 1)
DOWN_LEFT = (1, -1)

ZERO_BY_TWO = (0, 2)
TWO_BY_ZERO = (2, 0)
TWO_BY_TWO = (2, 2)
THREE_BY_THREE = (3, 3)

def identity(x):
    return x

def add(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return a + b
    elif isinstance(a, tuple) and isinstance(b, tuple):
        return (a[0] + b[0], a[1] + b[1])
    elif isinstance(a, int) and isinstance(b, tuple):
        return (a + b[0], a + b[1])
    elif isinstance(a, tuple) and isinstance(b, int):
        return (a[0] + b, a[1] + b)
    return (a, b)

def subtract(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return a - b
    elif isinstance(a, tuple) and isinstance(b, tuple):
        return (a[0] - b[0], a[1] - b[1])
    elif isinstance(a, int) and isinstance(b, tuple):
        return (a - b[0], a - b[1])
    elif isinstance(a, tuple) and isinstance(b, int):
        return (a[0] - b, a[1] - b)
    return (0, 0)

def multiply(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return a * b
    elif isinstance(a, tuple) and isinstance(b, tuple):
        return (a[0] * b[0], a[1] * b[1])
    elif isinstance(a, int) and isinstance(b, tuple):
        return (a * b[0], a * b[1])
    elif isinstance(a, tuple) and isinstance(b, int):
        return (a[0] * b, a[1] * b)
    return (0, 0)

def divide(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return a // b
    elif isinstance(a, tuple) and isinstance(b, tuple):
        return (a[0] // b[0], a[1] // b[1])
    elif isinstance(a, int) and isinstance(b, tuple):
        return (a // b[0], a // b[1])
    elif isinstance(a, tuple) and isinstance(b, int):
        return (a[0] // b, a[1] // b)
    return (0, 0)

def invert(n):
    return -n if isinstance(n, int) else (-n[0], -n[1])

def even(n):
    return n % 2 == 0

def double(n):
    return n * 2 if isinstance(n, int) else (n[0] * 2, n[1] * 2)

def halve(n):
    return n // 2 if isinstance(n, int) else (n[0] // 2, n[1] // 2)

def flip(b):
    return not b

def equality(a, b):
    return a == b

def contained(value, container):
    return value in container

def combine(a, b):
    if isinstance(a, tuple) and isinstance(b, tuple):
        return a + b
    if isinstance(a, frozenset) and isinstance(b, frozenset):
        return a | b
    return tuple(a) + tuple(b)

def intersection(a, b):
    return a & b

def difference(a, b):
    return type(a)((e for e in a if e not in b))

def dedupe(tup):
    return tuple((e for i, e in enumerate(tup) if tup.index(e) == i))

def order(container, compfunc):
    return tuple(sorted(container, key=compfunc))

def repeat(item, num):
    return tuple((item for i in range(num)))

def greater(a, b):
    return a > b

def size(container):
    return len(container)

def merge(containers):
    if isinstance(containers, frozenset):
        return frozenset((e for c in containers for e in c))
    return tuple((e for c in containers for e in c))

def maximum(container):
    return max(container, default=0)

def minimum(container):
    return min(container, default=0)

def valmax(container, compfunc):
    return compfunc(max(container, key=compfunc, default=0))

def valmin(container, compfunc):
    return compfunc(min(container, key=compfunc, default=0))

def argmax(container, compfunc):
    return max(container, key=compfunc)

def argmin(container, compfunc):
    return min(container, key=compfunc)

def mostcommon(container):
    seq = tuple(container)
    return max(set(seq), key=seq.count)

def leastcommon(container):
    seq = tuple(container)
    return min(set(seq), key=seq.count)

def initset(value):
    return frozenset({value})

def both(a, b):
    return a and b

def either(a, b):
    return a or b

def increment(x):
    return x + 1 if isinstance(x, int) else (x[0] + 1, x[1] + 1)

def decrement(x):
    return x - 1 if isinstance(x, int) else (x[0] - 1, x[1] - 1)

def crement(x):
    if isinstance(x, int):
        return 0 if x == 0 else x + 1 if x > 0 else x - 1
    return (0 if x[0] == 0 else x[0] + 1 if x[0] > 0 else x[0] - 1, 0 if x[1] == 0 else x[1] + 1 if x[1] > 0 else x[1] - 1)

def sign(x):
    if isinstance(x, int):
        return 0 if x == 0 else 1 if x > 0 else -1
    return (0 if x[0] == 0 else 1 if x[0] > 0 else -1, 0 if x[1] == 0 else 1 if x[1] > 0 else -1)

def positive(x):
    return x > 0

def toivec(i):
    return (i, 0)

def tojvec(j):
    return (0, j)

def sfilter(container, condition):
    return type(container)((e for e in container if condition(e)))

def mfilter(container, function):
    filtered = sfilter(container, function)
    if isinstance(filtered, frozenset):
        return frozenset((e for c in filtered for e in c))
    return tuple((e for c in filtered for e in c))

def extract(container, condition):
    return next((e for e in container if condition(e)))

def totuple(container):
    return tuple(container)

def first(container):
    return next(iter(container))

def last(container):
    return max(enumerate(container))[1]

def insert(value, container):
    return container.union(frozenset({value}))

def remove(value, container):
    return type(container)((e for e in container if e != value))

def other(container, value):
    return first(remove(value, container))

def interval(start, stop, step):
    return tuple(range(start, stop, step))

def astuple(a, b):
    return (a, b)

def product(a, b):
    return frozenset(((i, j) for j in b for i in a))

def pair(a, b):
    return tuple(zip(a, b))

def branch(condition, a, b):
    return a if condition else b

def compose(outer, inner):
    return lambda x: outer(inner(x))

def chain(h, g, f):
    return lambda x: h(g(f(x)))

def matcher(function, target):
    return lambda x: function(x) == target

def rbind(function, fixed):
    n = function.__code__.co_argcount
    if n == 2:
        return lambda x: function(x, fixed)
    elif n == 3:
        return lambda x, y: function(x, y, fixed)
    else:
        return lambda x, y, z: function(x, y, z, fixed)

def lbind(function, fixed):
    n = function.__code__.co_argcount
    if n == 2:
        return lambda y: function(fixed, y)
    elif n == 3:
        return lambda y, z: function(fixed, y, z)
    else:
        return lambda y, z, a: function(fixed, y, z, a)

def power(function, n):
    if n == 1:
        return function
    return compose(function, power(function, n - 1))

def fork(outer, a, b):
    return lambda x: outer(a(x), b(x))

def apply(function, container):
    return type(container)((function(e) for e in container))

def rapply(functions, value):
    return type(functions)((function(value) for function in functions))

def mapply(function, container):
    applied = apply(function, container)
    if isinstance(applied, frozenset):
        return frozenset((e for c in applied for e in c))
    return tuple((e for c in applied for e in c))

def papply(function, a, b):
    return tuple((function(i, j) for i, j in zip(a, b)))

def mpapply(function, a, b):
    results = tuple((function(i, j) for i, j in zip(a, b)))
    if not results:
        return tuple()
    first = results[0]
    if isinstance(first, frozenset):
        return frozenset((e for r in results for e in r))
    return tuple((e for r in results for e in r))

def prapply(function, a, b):
    return frozenset((function(i, j) for j in b for i in a))

def mostcolor(element):
    values = [v for r in element for v in r] if isinstance(element, tuple) else [v for v, _ in element]
    return max(set(values), key=values.count)

def leastcolor(element):
    values = [v for r in element for v in r] if isinstance(element, tuple) else [v for v, _ in element]
    return min(set(values), key=values.count)

def height(piece):
    if len(piece) == 0:
        return 0
    if isinstance(piece, tuple):
        return len(piece)
    return lowermost(piece) - uppermost(piece) + 1

def width(piece):
    if len(piece) == 0:
        return 0
    if isinstance(piece, tuple):
        return len(piece[0])
    return rightmost(piece) - leftmost(piece) + 1

def shape(piece):
    return (height(piece), width(piece))

def portrait(piece):
    return height(piece) > width(piece)

def colorcount(element, value):
    if isinstance(element, tuple):
        return sum((row.count(value) for row in element))
    return sum((v == value for v, _ in element))

def colorfilter(objs, value):
    return frozenset((obj for obj in objs if next(iter(obj))[0] == value))

def sizefilter(container, n):
    return frozenset((item for item in container if len(item) == n))

def asindices(grid):
    return frozenset(((i, j) for i in range(len(grid)) for j in range(len(grid[0]))))

def ofcolor(grid, value):
    return frozenset(((i, j) for i, r in enumerate(grid) for j, v in enumerate(r) if v == value))

def ulcorner(patch):
    idx = toindices(patch)
    return (min((i for i, _ in idx)), min((j for _, j in idx)))

def urcorner(patch):
    idx = toindices(patch)
    return (min((i for i, _ in idx)), max((j for _, j in idx)))

def llcorner(patch):
    idx = toindices(patch)
    return (max((i for i, _ in idx)), min((j for _, j in idx)))

def lrcorner(patch):
    idx = toindices(patch)
    return (max((i for i, _ in idx)), max((j for _, j in idx)))

def crop(grid, start, dims):
    return tuple((r[start[1]:start[1] + dims[1]] for r in grid[start[0]:start[0] + dims[0]]))

def toindices(patch):
    if len(patch) == 0:
        return frozenset()
    first = next(iter(patch))
    if isinstance(first, tuple) and len(first) == 2 and isinstance(first[1], tuple):
        obj = patch
        return frozenset((index for _, index in obj))
    return patch

def recolor(value, patch):
    return frozenset(((value, index) for index in toindices(patch)))

def shift(patch, directions):
    if len(patch) == 0:
        return patch
    di, dj = directions
    first = next(iter(patch))
    if isinstance(first, tuple) and len(first) == 2 and isinstance(first[1], tuple):
        obj = patch
        return frozenset(((value, (i + di, j + dj)) for value, (i, j) in obj))
    idx = patch
    return frozenset(((i + di, j + dj) for i, j in idx))

def normalize(patch):
    if len(patch) == 0:
        return patch
    return shift(patch, (-uppermost(patch), -leftmost(patch)))

def dneighbors(loc):
    return frozenset({(loc[0] - 1, loc[1]), (loc[0] + 1, loc[1]), (loc[0], loc[1] - 1), (loc[0], loc[1] + 1)})

def ineighbors(loc):
    return frozenset({(loc[0] - 1, loc[1] - 1), (loc[0] - 1, loc[1] + 1), (loc[0] + 1, loc[1] - 1), (loc[0] + 1, loc[1] + 1)})

def neighbors(loc):
    return dneighbors(loc) | ineighbors(loc)

def objects(grid, univalued, diagonal, without_bg):
    bg = mostcolor(grid) if without_bg else None
    objs = set()
    occupied = set()
    h, w = (len(grid), len(grid[0]))
    unvisited = asindices(grid)
    diagfun = neighbors if diagonal else dneighbors
    for loc in unvisited:
        if loc in occupied:
            continue
        val = grid[loc[0]][loc[1]]
        if val == bg:
            continue
        obj = {(val, loc)}
        cands = {loc}
        while len(cands) > 0:
            neighborhood = set()
            for cand in cands:
                v = grid[cand[0]][cand[1]]
                if val == v if univalued else v != bg:
                    obj.add((v, cand))
                    occupied.add(cand)
                    neighborhood |= {(i, j) for i, j in diagfun(cand) if 0 <= i < h and 0 <= j < w}
            cands = neighborhood - occupied
        objs.add(frozenset(obj))
    return frozenset(objs)

def partition(grid):
    return frozenset((frozenset(((v, (i, j)) for i, r in enumerate(grid) for j, v in enumerate(r) if v == value)) for value in palette(grid)))

def fgpartition(grid):
    return frozenset((frozenset(((v, (i, j)) for i, r in enumerate(grid) for j, v in enumerate(r) if v == value)) for value in palette(grid) - {mostcolor(grid)}))

def uppermost(patch):
    return min((i for i, j in toindices(patch)))

def lowermost(patch):
    return max((i for i, j in toindices(patch)))

def leftmost(patch):
    return min((j for i, j in toindices(patch)))

def rightmost(patch):
    return max((j for i, j in toindices(patch)))

def square(piece):
    return len(piece) == len(piece[0]) if isinstance(piece, tuple) else height(piece) * width(piece) == len(piece) and height(piece) == width(piece)

def vline(patch):
    return height(patch) == len(patch) and width(patch) == 1

def hline(patch):
    return width(patch) == len(patch) and height(patch) == 1

def hmatching(a, b):
    return len(set((i for i, j in toindices(a))) & set((i for i, j in toindices(b)))) > 0

def vmatching(a, b):
    return len(set((j for i, j in toindices(a))) & set((j for i, j in toindices(b)))) > 0

def manhattan(a, b):
    return min((abs(ai - bi) + abs(aj - bj) for ai, aj in toindices(a) for bi, bj in toindices(b)))

def adjacent(a, b):
    return manhattan(a, b) == 1

def bordering(patch, grid):
    return uppermost(patch) == 0 or leftmost(patch) == 0 or lowermost(patch) == len(grid) - 1 or (rightmost(patch) == len(grid[0]) - 1)

def centerofmass(patch):
    idx = toindices(patch)
    n = len(idx) if len(idx) > 0 else 1
    si = sum((i for i, _ in idx))
    sj = sum((j for _, j in idx))
    return (si // n, sj // n)

def palette(element):
    if isinstance(element, tuple):
        return frozenset({v for r in element for v in r})
    return frozenset({v for v, _ in element})

def numcolors(element):
    return len(palette(element))

def color(obj):
    return next(iter(obj))[0]

def toobject(patch, grid):
    h, w = (len(grid), len(grid[0]))
    return frozenset(((grid[i][j], (i, j)) for i, j in toindices(patch) if 0 <= i < h and 0 <= j < w))

def asobject(grid):
    return frozenset(((v, (i, j)) for i, r in enumerate(grid) for j, v in enumerate(r)))

def rot90(grid):
    return tuple((tuple(row) for row in zip(*grid[::-1])))

def rot180(grid):
    return tuple((tuple(row[::-1]) for row in grid[::-1]))

def rot270(grid):
    return tuple((tuple(row[::-1]) for row in zip(*grid[::-1])))[::-1]

def hmirror(piece):
    if isinstance(piece, tuple):
        return piece[::-1]
    d = ulcorner(piece)[0] + lrcorner(piece)[0]
    first = next(iter(piece))
    if isinstance(first, tuple) and len(first) == 2 and isinstance(first[1], tuple):
        obj = piece
        return frozenset(((v, (d - i, j)) for v, (i, j) in obj))
    idx = piece
    return frozenset(((d - i, j) for i, j in idx))

def vmirror(piece):
    if isinstance(piece, tuple):
        return tuple((row[::-1] for row in piece))
    d = ulcorner(piece)[1] + lrcorner(piece)[1]
    first = next(iter(piece))
    if isinstance(first, tuple) and len(first) == 2 and isinstance(first[1], tuple):
        obj = piece
        return frozenset(((v, (i, d - j)) for v, (i, j) in obj))
    idx = piece
    return frozenset(((i, d - j) for i, j in idx))

def dmirror(piece):
    if isinstance(piece, tuple):
        return tuple((tuple(row) for row in zip(*piece)))
    a, b = ulcorner(piece)
    first = next(iter(piece))
    if isinstance(first, tuple) and len(first) == 2 and isinstance(first[1], tuple):
        obj = piece
        return frozenset(((v, (j - b + a, i - a + b)) for v, (i, j) in obj))
    idx = piece
    return frozenset(((j - b + a, i - a + b) for i, j in idx))

def cmirror(piece):
    if isinstance(piece, tuple):
        return tuple((tuple(row) for row in zip(*(r[::-1] for r in piece[::-1]))))
    return vmirror(dmirror(vmirror(piece)))

def fill(grid, value, patch):
    h, w = (len(grid), len(grid[0]))
    grid_filled = list((list(row) for row in grid))
    for i, j in toindices(patch):
        if 0 <= i < h and 0 <= j < w:
            grid_filled[i][j] = value
    return tuple((tuple(row) for row in grid_filled))

def paint(grid, obj):
    h, w = (len(grid), len(grid[0]))
    grid_painted = list((list(row) for row in grid))
    for value, (i, j) in obj:
        if 0 <= i < h and 0 <= j < w:
            grid_painted[i][j] = value
    return tuple((tuple(row) for row in grid_painted))

def underfill(grid, value, patch):
    h, w = (len(grid), len(grid[0]))
    bg = mostcolor(grid)
    g = list((list(r) for r in grid))
    for i, j in toindices(patch):
        if 0 <= i < h and 0 <= j < w:
            if g[i][j] == bg:
                g[i][j] = value
    return tuple((tuple(r) for r in g))

def underpaint(grid, obj):
    h, w = (len(grid), len(grid[0]))
    bg = mostcolor(grid)
    g = list((list(r) for r in grid))
    for value, (i, j) in obj:
        if 0 <= i < h and 0 <= j < w:
            if g[i][j] == bg:
                g[i][j] = value
    return tuple((tuple(r) for r in g))

def hupscale(grid, factor):
    rows = []
    for row in grid:
        new_row = []
        for value in row:
            new_row.extend([value] * factor)
        rows.append(tuple(new_row))
    return tuple(rows)

def vupscale(grid, factor):
    return tuple((tuple(row) for row in grid for _ in range(factor)))

def upscale(element, factor):
    if isinstance(element, tuple):
        rows = []
        for row in element:
            expanded = []
            for value in row:
                expanded.extend([value] * factor)
            for _ in range(factor):
                rows.append(tuple(expanded))
        return tuple(rows)
    else:
        if len(element) == 0:
            return frozenset()
        di_inv, dj_inv = ulcorner(element)
        di, dj = (-di_inv, -dj_inv)
        normed_obj = shift(element, (di, dj))
        o = set()
        for value, (i, j) in normed_obj:
            for io in range(factor):
                for jo in range(factor):
                    o.add((value, (i * factor + io, j * factor + jo)))
        return shift(frozenset(o), (di_inv, dj_inv))

def downscale(grid, factor):
    return tuple((tuple(row[::factor]) for row in grid[::factor]))

def hconcat(a, b):
    return tuple((i + j for i, j in zip(a, b)))

def vconcat(a, b):
    return a + b

def subgrid(patch, grid):
    return crop(grid, ulcorner(patch), shape(patch))

def hsplit(grid, n):
    h, w = (len(grid), len(grid[0]) // n)
    offset = len(grid[0]) % n != 0
    return tuple((crop(grid, (0, w * i + i * offset), (h, w)) for i in range(n)))

def vsplit(grid, n):
    h, w = (len(grid) // n, len(grid[0]))
    offset = len(grid) % n != 0
    return tuple((crop(grid, (h * i + i * offset, 0), (h, w)) for i in range(n)))

def cellwise(a, b, fallback):
    h, w = (len(a), len(a[0]))
    rows = []
    for i in range(h):
        row_vals = []
        for j in range(w):
            av = a[i][j]
            row_vals.append(av if av == b[i][j] else fallback)
        rows.append(tuple(row_vals))
    return tuple(rows)

def replace(grid, replacee, replacer):
    return tuple((tuple((replacer if v == replacee else v for v in r)) for r in grid))

def switch(grid, a, b):
    return tuple((tuple((v if v != a and v != b else {a: b, b: a}[v] for v in r)) for r in grid))

def center(patch):
    return (uppermost(patch) + height(patch) // 2, leftmost(patch) + width(patch) // 2)

def position(a, b):
    ia, ja = center(toindices(a))
    ib, jb = center(toindices(b))
    if ia == ib:
        return (0, 1 if ja < jb else -1)
    elif ja == jb:
        return (1 if ia < ib else -1, 0)
    elif ia < ib:
        return (1, 1 if ja < jb else -1)
    elif ia > ib:
        return (-1, 1 if ja < jb else -1)
    return (0, 0)

def index(grid, loc):
    i, j = loc
    h, w = (len(grid), len(grid[0]))
    if not (0 <= i < h and 0 <= j < w):
        return None
    return grid[loc[0]][loc[1]]

def canvas(value, dimensions):
    return tuple((tuple((value for j in range(dimensions[1]))) for i in range(dimensions[0])))

def corners(patch):
    return frozenset({ulcorner(patch), urcorner(patch), llcorner(patch), lrcorner(patch)})

def connect(a, b):
    ai, aj = a
    bi, bj = b
    si = min(ai, bi)
    ei = max(ai, bi) + 1
    sj = min(aj, bj)
    ej = max(aj, bj) + 1
    if ai == bi:
        return frozenset(((ai, j) for j in range(sj, ej)))
    elif aj == bj:
        return frozenset(((i, aj) for i in range(si, ei)))
    elif bi - ai == bj - aj:
        return frozenset(((i, j) for i, j in zip(range(si, ei), range(sj, ej))))
    elif bi - ai == aj - bj:
        return frozenset(((i, j) for i, j in zip(range(si, ei), range(ej - 1, sj - 1, -1))))
    return frozenset()

def cover(grid, patch):
    return fill(grid, mostcolor(grid), toindices(patch))

def trim(grid):
    return tuple((r[1:-1] for r in grid[1:-1]))

def move(grid, obj, offset):
    return paint(cover(grid, obj), shift(obj, offset))

def tophalf(grid):
    return grid[:len(grid) // 2]

def bottomhalf(grid):
    return grid[len(grid) // 2 + len(grid) % 2:]

def lefthalf(grid):
    return rot270(tophalf(rot90(grid)))

def righthalf(grid):
    return rot270(bottomhalf(rot90(grid)))

def vfrontier(location):
    return frozenset(((i, location[1]) for i in range(30)))

def hfrontier(location):
    return frozenset(((location[0], j) for j in range(30)))

def backdrop(patch):
    if len(patch) == 0:
        return frozenset({})
    indices = toindices(patch)
    si, sj = ulcorner(indices)
    ei, ej = lrcorner(patch)
    return frozenset(((i, j) for i in range(si, ei + 1) for j in range(sj, ej + 1)))

def delta(patch):
    if len(patch) == 0:
        return frozenset({})
    return backdrop(patch) - toindices(patch)

def gravitate(source, destination):
    si, sj = center(source)
    di, dj = center(destination)
    i, j = (0, 0)
    if vmatching(source, destination):
        i = 1 if si < di else -1
    else:
        j = 1 if sj < dj else -1
    gi, gj = (i, j)
    c = 0
    while not adjacent(source, destination) and c < 42:
        c += 1
        gi += i
        gj += j
        source = shift(source, (i, j))
    return (gi - i, gj - j)

def inbox(patch):
    ai, aj = (uppermost(patch) + 1, leftmost(patch) + 1)
    bi, bj = (lowermost(patch) - 1, rightmost(patch) - 1)
    si, sj = (min(ai, bi), min(aj, bj))
    ei, ej = (max(ai, bi), max(aj, bj))
    vlines = {(i, sj) for i in range(si, ei + 1)} | {(i, ej) for i in range(si, ei + 1)}
    hlines = {(si, j) for j in range(sj, ej + 1)} | {(ei, j) for j in range(sj, ej + 1)}
    return frozenset(vlines | hlines)

def outbox(patch):
    ai, aj = (uppermost(patch) - 1, leftmost(patch) - 1)
    bi, bj = (lowermost(patch) + 1, rightmost(patch) + 1)
    si, sj = (min(ai, bi), min(aj, bj))
    ei, ej = (max(ai, bi), max(aj, bj))
    vlines = {(i, sj) for i in range(si, ei + 1)} | {(i, ej) for i in range(si, ei + 1)}
    hlines = {(si, j) for j in range(sj, ej + 1)} | {(ei, j) for j in range(sj, ej + 1)}
    return frozenset(vlines | hlines)

def box(patch):
    if len(patch) == 0:
        return frozenset()
    ai, aj = ulcorner(patch)
    bi, bj = lrcorner(patch)
    si, sj = (min(ai, bi), min(aj, bj))
    ei, ej = (max(ai, bi), max(aj, bj))
    vlines = {(i, sj) for i in range(si, ei + 1)} | {(i, ej) for i in range(si, ei + 1)}
    hlines = {(si, j) for j in range(sj, ej + 1)} | {(ei, j) for j in range(sj, ej + 1)}
    return frozenset(vlines | hlines)

def shoot(start, direction):
    return connect(start, (start[0] + 42 * direction[0], start[1] + 42 * direction[1]))

def occurrences(grid, obj):
    occs = set()
    normed = normalize(obj)
    h, w = (len(grid), len(grid[0]))
    oh, ow = shape(obj)
    h2, w2 = (h - oh + 1, w - ow + 1)
    for i in range(h2):
        for j in range(w2):
            occurs = True
            for v, (a, b) in shift(normed, (i, j)):
                if not (0 <= a < h and 0 <= b < w and (grid[a][b] == v)):
                    occurs = False
                    break
            if occurs:
                occs.add((i, j))
    return frozenset(occs)

def frontiers(grid):
    h, w = (len(grid), len(grid[0]))
    row_indices = tuple((i for i, r in enumerate(grid) if len(set(r)) == 1))
    column_indices = tuple((j for j, c in enumerate(dmirror(grid)) if len(set(c)) == 1))
    hfrontiers = frozenset({frozenset({(grid[i][j], (i, j)) for j in range(w)}) for i in row_indices})
    vfrontiers = frozenset({frozenset({(grid[i][j], (i, j)) for i in range(h)}) for j in column_indices})
    return hfrontiers | vfrontiers

def compress(grid):
    ri = tuple((i for i, r in enumerate(grid) if len(set(r)) == 1))
    ci = tuple((j for j, c in enumerate(dmirror(grid)) if len(set(c)) == 1))
    return tuple((tuple((v for j, v in enumerate(r) if j not in ci)) for i, r in enumerate(grid) if i not in ri))

def hperiod(obj):
    normalized = normalize(obj)
    w = width(normalized)
    for p in range(1, w):
        offsetted = shift(normalized, (0, -p))
        pruned = frozenset({(c, (i, j)) for c, (i, j) in offsetted if j >= 0})
        if pruned.issubset(normalized):
            return p
    return w

def vperiod(obj):
    normalized = normalize(obj)
    h = height(normalized)
    for p in range(1, h):
        offsetted = shift(normalized, (-p, 0))
        pruned = frozenset({(c, (i, j)) for c, (i, j) in offsetted if i >= 0})
        if pruned.issubset(normalized):
            return p
    return h

def solve_bc1d5164(I):
    x1 = leastcolor(I)
    x2 = crop(I, ORIGIN, THREE_BY_THREE)
    x3 = crop(I, TWO_BY_ZERO, THREE_BY_THREE)
    x4 = tojvec(FOUR)
    x5 = crop(I, x4, THREE_BY_THREE)
    x6 = astuple(TWO, FOUR)
    x7 = crop(I, x6, THREE_BY_THREE)
    x8 = canvas(ZERO, THREE_BY_THREE)
    x9 = rbind(ofcolor, x1)
    x10 = astuple(x2, x3)
    x11 = astuple(x5, x7)
    x12 = combine(x10, x11)
    x13 = mapply(x9, x12)
    O = fill(x8, x1, x13)
    return O

def p(g):
    return solve_bc1d5164(g)
